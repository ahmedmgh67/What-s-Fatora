<?php

namespace Dingo\Api\Exception;

class StoreResourceFailedException extends ResourceException
{
    //
}
