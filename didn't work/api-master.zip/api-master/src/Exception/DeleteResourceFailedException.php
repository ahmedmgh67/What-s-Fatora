<?php

namespace Dingo\Api\Exception;

class DeleteResourceFailedException extends ResourceException
{
    //
}
