package android.support.v4.content.pm;

public final class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              H:\As A Bussines Man\confedince\App Dev Department\What's Fatora\Tawseel APK\Client\dex2jar-2.0\t-dex2jar.jar!\android\support\v4\content\pm\ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */