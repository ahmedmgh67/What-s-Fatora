package android.support.v4.animation;

import android.view.View;

abstract interface AnimatorProvider
{
  public abstract void clearInterpolator(View paramView);
  
  public abstract ValueAnimatorCompat emptyValueAnimator();
}


/* Location:              H:\As A Bussines Man\confedince\App Dev Department\What's Fatora\Tawseel APK\Client\dex2jar-2.0\t-dex2jar.jar!\android\support\v4\animation\AnimatorProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */