package android.support.transition;

import android.annotation.TargetApi;
import android.support.annotation.RequiresApi;
import android.transition.Transition;

@TargetApi(23)
@RequiresApi(23)
class TransitionApi23
  extends TransitionKitKat
{
  public TransitionImpl removeTarget(int paramInt)
  {
    this.mTransition.removeTarget(paramInt);
    return this;
  }
}


/* Location:              H:\As A Bussines Man\confedince\App Dev Department\What's Fatora\Tawseel APK\Client\dex2jar-2.0\t-dex2jar.jar!\android\support\transition\TransitionApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */