package android.support.transition;

import android.graphics.Rect;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.view.ViewGroup;

public class SidePropagation
  extends VisibilityPropagation
{
  private float mPropagationSpeed = 3.0F;
  private int mSide = 80;
  
  private int distance(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    int i;
    if (this.mSide == 8388611) {
      if (ViewCompat.getLayoutDirection(paramView) == 1)
      {
        i = 1;
        label20:
        if (i == 0) {
          break label80;
        }
        i = 5;
      }
    }
    for (;;)
    {
      switch (i)
      {
      default: 
        return 0;
        i = 0;
        break label20;
        label80:
        i = 3;
        continue;
        if (this.mSide == 8388613)
        {
          if (ViewCompat.getLayoutDirection(paramView) == 1)
          {
            i = 1;
            label106:
            if (i == 0) {
              break label123;
            }
          }
          label123:
          for (i = 3;; i = 5)
          {
            break;
            i = 0;
            break label106;
          }
        }
        i = this.mSide;
      }
    }
    return paramInt7 - paramInt1 + Math.abs(paramInt4 - paramInt2);
    return paramInt8 - paramInt2 + Math.abs(paramInt3 - paramInt1);
    return paramInt1 - paramInt5 + Math.abs(paramInt4 - paramInt2);
    return paramInt2 - paramInt6 + Math.abs(paramInt3 - paramInt1);
  }
  
  private int getMaxDistance(ViewGroup paramViewGroup)
  {
    switch (this.mSide)
    {
    default: 
      return paramViewGroup.getHeight();
    }
    return paramViewGroup.getWidth();
  }
  
  public long getStartDelay(ViewGroup paramViewGroup, Transition paramTransition, TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2)
  {
    if ((paramTransitionValues1 == null) && (paramTransitionValues2 == null)) {
      return 0L;
    }
    int i = 1;
    Rect localRect = paramTransition.getEpicenter();
    int m;
    int n;
    int i1;
    int i2;
    int i3;
    int i4;
    int j;
    if ((paramTransitionValues2 == null) || (getViewVisibility(paramTransitionValues1) == 0))
    {
      i = -1;
      m = getViewX(paramTransitionValues1);
      n = getViewY(paramTransitionValues1);
      paramTransitionValues1 = new int[2];
      paramViewGroup.getLocationOnScreen(paramTransitionValues1);
      i1 = paramTransitionValues1[0] + Math.round(paramViewGroup.getTranslationX());
      i2 = paramTransitionValues1[1] + Math.round(paramViewGroup.getTranslationY());
      i3 = i1 + paramViewGroup.getWidth();
      i4 = i2 + paramViewGroup.getHeight();
      if (localRect == null) {
        break label201;
      }
      j = localRect.centerX();
    }
    for (int k = localRect.centerY();; k = (i2 + i4) / 2)
    {
      float f = distance(paramViewGroup, m, n, j, k, i1, i2, i3, i4) / getMaxDistance(paramViewGroup);
      long l2 = paramTransition.getDuration();
      long l1 = l2;
      if (l2 < 0L) {
        l1 = 300L;
      }
      return Math.round((float)(i * l1) / this.mPropagationSpeed * f);
      paramTransitionValues1 = paramTransitionValues2;
      break;
      label201:
      j = (i1 + i3) / 2;
    }
  }
  
  public void setPropagationSpeed(float paramFloat)
  {
    if (paramFloat == 0.0F) {
      throw new IllegalArgumentException("propagationSpeed may not be 0");
    }
    this.mPropagationSpeed = paramFloat;
  }
  
  public void setSide(int paramInt)
  {
    this.mSide = paramInt;
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\SidePropagation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */