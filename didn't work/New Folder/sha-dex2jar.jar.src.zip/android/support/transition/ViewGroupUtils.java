package android.support.transition;

import android.os.Build.VERSION;
import android.support.annotation.NonNull;
import android.view.ViewGroup;

class ViewGroupUtils
{
  private static final ViewGroupUtilsImpl IMPL = new ViewGroupUtilsApi14();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 18)
    {
      IMPL = new ViewGroupUtilsApi18();
      return;
    }
  }
  
  static ViewGroupOverlayImpl getOverlay(@NonNull ViewGroup paramViewGroup)
  {
    return IMPL.getOverlay(paramViewGroup);
  }
  
  static void suppressLayout(@NonNull ViewGroup paramViewGroup, boolean paramBoolean)
  {
    IMPL.suppressLayout(paramViewGroup, paramBoolean);
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\ViewGroupUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */