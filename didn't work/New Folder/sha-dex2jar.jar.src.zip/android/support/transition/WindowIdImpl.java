package android.support.transition;

import android.support.annotation.RequiresApi;

@RequiresApi(14)
abstract interface WindowIdImpl {}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\WindowIdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */