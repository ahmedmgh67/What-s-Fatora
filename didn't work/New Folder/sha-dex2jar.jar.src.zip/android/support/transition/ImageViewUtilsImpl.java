package android.support.transition;

import android.animation.Animator;
import android.graphics.Matrix;
import android.support.annotation.RequiresApi;
import android.widget.ImageView;

@RequiresApi(14)
abstract interface ImageViewUtilsImpl
{
  public abstract void animateTransform(ImageView paramImageView, Matrix paramMatrix);
  
  public abstract void reserveEndAnimateTransform(ImageView paramImageView, Animator paramAnimator);
  
  public abstract void startAnimateTransform(ImageView paramImageView);
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\ImageViewUtilsImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */