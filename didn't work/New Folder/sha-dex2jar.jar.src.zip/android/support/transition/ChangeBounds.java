package android.support.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

public class ChangeBounds
  extends Transition
{
  private static final Property<View, PointF> BOTTOM_RIGHT_ONLY_PROPERTY;
  private static final Property<ViewBounds, PointF> BOTTOM_RIGHT_PROPERTY;
  private static final Property<Drawable, PointF> DRAWABLE_ORIGIN_PROPERTY;
  private static final Property<View, PointF> POSITION_PROPERTY = new Property(PointF.class, "position")
  {
    public PointF get(View paramAnonymousView)
    {
      return null;
    }
    
    public void set(View paramAnonymousView, PointF paramAnonymousPointF)
    {
      int i = Math.round(paramAnonymousPointF.x);
      int j = Math.round(paramAnonymousPointF.y);
      ViewUtils.setLeftTopRightBottom(paramAnonymousView, i, j, i + paramAnonymousView.getWidth(), j + paramAnonymousView.getHeight());
    }
  };
  private static final String PROPNAME_BOUNDS = "android:changeBounds:bounds";
  private static final String PROPNAME_CLIP = "android:changeBounds:clip";
  private static final String PROPNAME_PARENT = "android:changeBounds:parent";
  private static final String PROPNAME_WINDOW_X = "android:changeBounds:windowX";
  private static final String PROPNAME_WINDOW_Y = "android:changeBounds:windowY";
  private static final Property<View, PointF> TOP_LEFT_ONLY_PROPERTY;
  private static final Property<ViewBounds, PointF> TOP_LEFT_PROPERTY;
  private static RectEvaluator sRectEvaluator = new RectEvaluator();
  private static final String[] sTransitionProperties = { "android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY" };
  private boolean mReparent = false;
  private boolean mResizeClip = false;
  private int[] mTempLocation = new int[2];
  
  static
  {
    DRAWABLE_ORIGIN_PROPERTY = new Property(PointF.class, "boundsOrigin")
    {
      private Rect mBounds = new Rect();
      
      public PointF get(Drawable paramAnonymousDrawable)
      {
        paramAnonymousDrawable.copyBounds(this.mBounds);
        return new PointF(this.mBounds.left, this.mBounds.top);
      }
      
      public void set(Drawable paramAnonymousDrawable, PointF paramAnonymousPointF)
      {
        paramAnonymousDrawable.copyBounds(this.mBounds);
        this.mBounds.offsetTo(Math.round(paramAnonymousPointF.x), Math.round(paramAnonymousPointF.y));
        paramAnonymousDrawable.setBounds(this.mBounds);
      }
    };
    TOP_LEFT_PROPERTY = new Property(PointF.class, "topLeft")
    {
      public PointF get(ChangeBounds.ViewBounds paramAnonymousViewBounds)
      {
        return null;
      }
      
      public void set(ChangeBounds.ViewBounds paramAnonymousViewBounds, PointF paramAnonymousPointF)
      {
        paramAnonymousViewBounds.setTopLeft(paramAnonymousPointF);
      }
    };
    BOTTOM_RIGHT_PROPERTY = new Property(PointF.class, "bottomRight")
    {
      public PointF get(ChangeBounds.ViewBounds paramAnonymousViewBounds)
      {
        return null;
      }
      
      public void set(ChangeBounds.ViewBounds paramAnonymousViewBounds, PointF paramAnonymousPointF)
      {
        paramAnonymousViewBounds.setBottomRight(paramAnonymousPointF);
      }
    };
    BOTTOM_RIGHT_ONLY_PROPERTY = new Property(PointF.class, "bottomRight")
    {
      public PointF get(View paramAnonymousView)
      {
        return null;
      }
      
      public void set(View paramAnonymousView, PointF paramAnonymousPointF)
      {
        ViewUtils.setLeftTopRightBottom(paramAnonymousView, paramAnonymousView.getLeft(), paramAnonymousView.getTop(), Math.round(paramAnonymousPointF.x), Math.round(paramAnonymousPointF.y));
      }
    };
    TOP_LEFT_ONLY_PROPERTY = new Property(PointF.class, "topLeft")
    {
      public PointF get(View paramAnonymousView)
      {
        return null;
      }
      
      public void set(View paramAnonymousView, PointF paramAnonymousPointF)
      {
        ViewUtils.setLeftTopRightBottom(paramAnonymousView, Math.round(paramAnonymousPointF.x), Math.round(paramAnonymousPointF.y), paramAnonymousView.getRight(), paramAnonymousView.getBottom());
      }
    };
  }
  
  public ChangeBounds() {}
  
  public ChangeBounds(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, Styleable.CHANGE_BOUNDS);
    boolean bool = TypedArrayUtils.getNamedBoolean(paramContext, (XmlResourceParser)paramAttributeSet, "resizeClip", 0, false);
    paramContext.recycle();
    setResizeClip(bool);
  }
  
  private void captureValues(TransitionValues paramTransitionValues)
  {
    View localView = paramTransitionValues.view;
    if ((ViewCompat.isLaidOut(localView)) || (localView.getWidth() != 0) || (localView.getHeight() != 0))
    {
      paramTransitionValues.values.put("android:changeBounds:bounds", new Rect(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom()));
      paramTransitionValues.values.put("android:changeBounds:parent", paramTransitionValues.view.getParent());
      if (this.mReparent)
      {
        paramTransitionValues.view.getLocationInWindow(this.mTempLocation);
        paramTransitionValues.values.put("android:changeBounds:windowX", Integer.valueOf(this.mTempLocation[0]));
        paramTransitionValues.values.put("android:changeBounds:windowY", Integer.valueOf(this.mTempLocation[1]));
      }
      if (this.mResizeClip) {
        paramTransitionValues.values.put("android:changeBounds:clip", ViewCompat.getClipBounds(localView));
      }
    }
  }
  
  private boolean parentMatches(View paramView1, View paramView2)
  {
    TransitionValues localTransitionValues;
    if (this.mReparent)
    {
      localTransitionValues = getMatchedTransitionValues(paramView1, true);
      if (localTransitionValues != null) {
        break label27;
      }
      if (paramView1 != paramView2) {}
    }
    else
    {
      return true;
    }
    return false;
    label27:
    return paramView2 == localTransitionValues.view;
  }
  
  public void captureEndValues(@NonNull TransitionValues paramTransitionValues)
  {
    captureValues(paramTransitionValues);
  }
  
  public void captureStartValues(@NonNull TransitionValues paramTransitionValues)
  {
    captureValues(paramTransitionValues);
  }
  
  @Nullable
  public Animator createAnimator(@NonNull final ViewGroup paramViewGroup, @Nullable final TransitionValues paramTransitionValues1, @Nullable final TransitionValues paramTransitionValues2)
  {
    if ((paramTransitionValues1 == null) || (paramTransitionValues2 == null))
    {
      paramTransitionValues1 = null;
      return paramTransitionValues1;
    }
    final Object localObject1 = paramTransitionValues1.values;
    Object localObject2 = paramTransitionValues2.values;
    localObject1 = (ViewGroup)((Map)localObject1).get("android:changeBounds:parent");
    localObject2 = (ViewGroup)((Map)localObject2).get("android:changeBounds:parent");
    if ((localObject1 == null) || (localObject2 == null)) {
      return null;
    }
    final View localView = paramTransitionValues2.view;
    int m;
    int k;
    int j;
    int i;
    if (parentMatches((View)localObject1, (View)localObject2))
    {
      paramViewGroup = (Rect)paramTransitionValues1.values.get("android:changeBounds:bounds");
      localObject1 = (Rect)paramTransitionValues2.values.get("android:changeBounds:bounds");
      m = paramViewGroup.left;
      final int n = ((Rect)localObject1).left;
      int i1 = paramViewGroup.top;
      final int i2 = ((Rect)localObject1).top;
      int i3 = paramViewGroup.right;
      final int i4 = ((Rect)localObject1).right;
      int i5 = paramViewGroup.bottom;
      final int i6 = ((Rect)localObject1).bottom;
      int i7 = i3 - m;
      int i8 = i5 - i1;
      int i9 = i4 - n;
      int i10 = i6 - i2;
      paramViewGroup = (Rect)paramTransitionValues1.values.get("android:changeBounds:clip");
      localObject1 = (Rect)paramTransitionValues2.values.get("android:changeBounds:clip");
      k = 0;
      j = 0;
      if ((i7 == 0) || (i8 == 0))
      {
        i = k;
        if (i9 != 0)
        {
          i = k;
          if (i10 == 0) {}
        }
      }
      else
      {
        if ((m != n) || (i1 != i2)) {
          j = 0 + 1;
        }
        if (i3 == i4)
        {
          i = j;
          if (i5 == i6) {}
        }
        else
        {
          i = j + 1;
        }
      }
      if ((paramViewGroup == null) || (paramViewGroup.equals(localObject1)))
      {
        j = i;
        if (paramViewGroup == null)
        {
          j = i;
          if (localObject1 == null) {}
        }
      }
      else
      {
        j = i + 1;
      }
      if (j > 0)
      {
        if (!this.mResizeClip)
        {
          ViewUtils.setLeftTopRightBottom(localView, m, i1, i3, i5);
          if (j == 2) {
            if ((i7 == i9) && (i8 == i10))
            {
              paramViewGroup = getPathMotion().getPath(m, i1, n, i2);
              paramViewGroup = ObjectAnimatorUtils.ofPointF(localView, POSITION_PROPERTY, paramViewGroup);
            }
          }
        }
        for (;;)
        {
          paramTransitionValues1 = paramViewGroup;
          if (!(localView.getParent() instanceof ViewGroup)) {
            break;
          }
          paramTransitionValues1 = (ViewGroup)localView.getParent();
          ViewGroupUtils.suppressLayout(paramTransitionValues1, true);
          addListener(new TransitionListenerAdapter()
          {
            boolean mCanceled = false;
            
            public void onTransitionCancel(@NonNull Transition paramAnonymousTransition)
            {
              ViewGroupUtils.suppressLayout(paramTransitionValues1, false);
              this.mCanceled = true;
            }
            
            public void onTransitionEnd(@NonNull Transition paramAnonymousTransition)
            {
              if (!this.mCanceled) {
                ViewGroupUtils.suppressLayout(paramTransitionValues1, false);
              }
              paramAnonymousTransition.removeListener(this);
            }
            
            public void onTransitionPause(@NonNull Transition paramAnonymousTransition)
            {
              ViewGroupUtils.suppressLayout(paramTransitionValues1, false);
            }
            
            public void onTransitionResume(@NonNull Transition paramAnonymousTransition)
            {
              ViewGroupUtils.suppressLayout(paramTransitionValues1, true);
            }
          });
          return paramViewGroup;
          paramTransitionValues2 = new ViewBounds(localView);
          paramViewGroup = getPathMotion().getPath(m, i1, n, i2);
          paramViewGroup = ObjectAnimatorUtils.ofPointF(paramTransitionValues2, TOP_LEFT_PROPERTY, paramViewGroup);
          paramTransitionValues1 = getPathMotion().getPath(i3, i5, i4, i6);
          localObject1 = ObjectAnimatorUtils.ofPointF(paramTransitionValues2, BOTTOM_RIGHT_PROPERTY, paramTransitionValues1);
          paramTransitionValues1 = new AnimatorSet();
          paramTransitionValues1.playTogether(new Animator[] { paramViewGroup, localObject1 });
          paramViewGroup = paramTransitionValues1;
          paramTransitionValues1.addListener(new AnimatorListenerAdapter()
          {
            private ChangeBounds.ViewBounds mViewBounds = paramTransitionValues2;
          });
          continue;
          if ((m != n) || (i1 != i2))
          {
            paramViewGroup = getPathMotion().getPath(m, i1, n, i2);
            paramViewGroup = ObjectAnimatorUtils.ofPointF(localView, TOP_LEFT_ONLY_PROPERTY, paramViewGroup);
          }
          else
          {
            paramViewGroup = getPathMotion().getPath(i3, i5, i4, i6);
            paramViewGroup = ObjectAnimatorUtils.ofPointF(localView, BOTTOM_RIGHT_ONLY_PROPERTY, paramViewGroup);
            continue;
            ViewUtils.setLeftTopRightBottom(localView, m, i1, m + Math.max(i7, i9), i1 + Math.max(i8, i10));
            paramTransitionValues1 = null;
            if ((m != n) || (i1 != i2))
            {
              paramTransitionValues1 = getPathMotion().getPath(m, i1, n, i2);
              paramTransitionValues1 = ObjectAnimatorUtils.ofPointF(localView, POSITION_PROPERTY, paramTransitionValues1);
            }
            paramTransitionValues2 = paramViewGroup;
            if (paramViewGroup == null) {
              paramTransitionValues2 = new Rect(0, 0, i7, i8);
            }
            paramViewGroup = (ViewGroup)localObject1;
            if (localObject1 == null) {
              paramViewGroup = new Rect(0, 0, i9, i10);
            }
            localObject2 = paramViewGroup;
            paramViewGroup = null;
            if (!paramTransitionValues2.equals(localObject2))
            {
              ViewCompat.setClipBounds(localView, paramTransitionValues2);
              paramViewGroup = ObjectAnimator.ofObject(localView, "clipBounds", sRectEvaluator, new Object[] { paramTransitionValues2, localObject2 });
              paramViewGroup.addListener(new AnimatorListenerAdapter()
              {
                private boolean mIsCanceled;
                
                public void onAnimationCancel(Animator paramAnonymousAnimator)
                {
                  this.mIsCanceled = true;
                }
                
                public void onAnimationEnd(Animator paramAnonymousAnimator)
                {
                  if (!this.mIsCanceled)
                  {
                    ViewCompat.setClipBounds(localView, localObject1);
                    ViewUtils.setLeftTopRightBottom(localView, n, i2, i4, i6);
                  }
                }
              });
            }
            paramViewGroup = TransitionUtils.mergeAnimators(paramTransitionValues1, paramViewGroup);
          }
        }
      }
    }
    else
    {
      i = ((Integer)paramTransitionValues1.values.get("android:changeBounds:windowX")).intValue();
      j = ((Integer)paramTransitionValues1.values.get("android:changeBounds:windowY")).intValue();
      k = ((Integer)paramTransitionValues2.values.get("android:changeBounds:windowX")).intValue();
      m = ((Integer)paramTransitionValues2.values.get("android:changeBounds:windowY")).intValue();
      if ((i != k) || (j != m))
      {
        paramViewGroup.getLocationInWindow(this.mTempLocation);
        paramTransitionValues1 = Bitmap.createBitmap(localView.getWidth(), localView.getHeight(), Bitmap.Config.ARGB_8888);
        localView.draw(new Canvas(paramTransitionValues1));
        paramTransitionValues1 = new BitmapDrawable(paramTransitionValues1);
        final float f = ViewUtils.getTransitionAlpha(localView);
        ViewUtils.setTransitionAlpha(localView, 0.0F);
        ViewUtils.getOverlay(paramViewGroup).add(paramTransitionValues1);
        paramTransitionValues2 = getPathMotion().getPath(i - this.mTempLocation[0], j - this.mTempLocation[1], k - this.mTempLocation[0], m - this.mTempLocation[1]);
        paramTransitionValues2 = ObjectAnimator.ofPropertyValuesHolder(paramTransitionValues1, new PropertyValuesHolder[] { PropertyValuesHolderUtils.ofPointF(DRAWABLE_ORIGIN_PROPERTY, paramTransitionValues2) });
        paramTransitionValues2.addListener(new AnimatorListenerAdapter()
        {
          public void onAnimationEnd(Animator paramAnonymousAnimator)
          {
            ViewUtils.getOverlay(paramViewGroup).remove(paramTransitionValues1);
            ViewUtils.setTransitionAlpha(localView, f);
          }
        });
        return paramTransitionValues2;
      }
    }
    return null;
  }
  
  public boolean getResizeClip()
  {
    return this.mResizeClip;
  }
  
  @Nullable
  public String[] getTransitionProperties()
  {
    return sTransitionProperties;
  }
  
  public void setResizeClip(boolean paramBoolean)
  {
    this.mResizeClip = paramBoolean;
  }
  
  private static class ViewBounds
  {
    private int mBottom;
    private int mBottomRightCalls;
    private int mLeft;
    private int mRight;
    private int mTop;
    private int mTopLeftCalls;
    private View mView;
    
    ViewBounds(View paramView)
    {
      this.mView = paramView;
    }
    
    private void setLeftTopRightBottom()
    {
      ViewUtils.setLeftTopRightBottom(this.mView, this.mLeft, this.mTop, this.mRight, this.mBottom);
      this.mTopLeftCalls = 0;
      this.mBottomRightCalls = 0;
    }
    
    void setBottomRight(PointF paramPointF)
    {
      this.mRight = Math.round(paramPointF.x);
      this.mBottom = Math.round(paramPointF.y);
      this.mBottomRightCalls += 1;
      if (this.mTopLeftCalls == this.mBottomRightCalls) {
        setLeftTopRightBottom();
      }
    }
    
    void setTopLeft(PointF paramPointF)
    {
      this.mLeft = Math.round(paramPointF.x);
      this.mTop = Math.round(paramPointF.y);
      this.mTopLeftCalls += 1;
      if (this.mTopLeftCalls == this.mBottomRightCalls) {
        setLeftTopRightBottom();
      }
    }
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\ChangeBounds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */