package android.support.transition;

import android.animation.ObjectAnimator;
import android.graphics.Path;
import android.graphics.PointF;
import android.util.Property;

abstract interface ObjectAnimatorUtilsImpl
{
  public abstract <T> ObjectAnimator ofPointF(T paramT, Property<T, PointF> paramProperty, Path paramPath);
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\ObjectAnimatorUtilsImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */