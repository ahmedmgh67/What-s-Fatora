package android.support.transition;

import android.support.annotation.NonNull;

public class TransitionListenerAdapter
  implements Transition.TransitionListener
{
  public void onTransitionCancel(@NonNull Transition paramTransition) {}
  
  public void onTransitionEnd(@NonNull Transition paramTransition) {}
  
  public void onTransitionPause(@NonNull Transition paramTransition) {}
  
  public void onTransitionResume(@NonNull Transition paramTransition) {}
  
  public void onTransitionStart(@NonNull Transition paramTransition) {}
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\TransitionListenerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */