package android.support.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.TypedArrayUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Map;

public abstract class Visibility
  extends Transition
{
  public static final int MODE_IN = 1;
  public static final int MODE_OUT = 2;
  private static final String PROPNAME_PARENT = "android:visibility:parent";
  private static final String PROPNAME_SCREEN_LOCATION = "android:visibility:screenLocation";
  static final String PROPNAME_VISIBILITY = "android:visibility:visibility";
  private static final String[] sTransitionProperties = { "android:visibility:visibility", "android:visibility:parent" };
  private int mMode = 3;
  
  public Visibility() {}
  
  public Visibility(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, Styleable.VISIBILITY_TRANSITION);
    int i = TypedArrayUtils.getNamedInt(paramContext, (XmlResourceParser)paramAttributeSet, "transitionVisibilityMode", 0, 0);
    paramContext.recycle();
    if (i != 0) {
      setMode(i);
    }
  }
  
  private void captureValues(TransitionValues paramTransitionValues)
  {
    int i = paramTransitionValues.view.getVisibility();
    paramTransitionValues.values.put("android:visibility:visibility", Integer.valueOf(i));
    paramTransitionValues.values.put("android:visibility:parent", paramTransitionValues.view.getParent());
    int[] arrayOfInt = new int[2];
    paramTransitionValues.view.getLocationOnScreen(arrayOfInt);
    paramTransitionValues.values.put("android:visibility:screenLocation", arrayOfInt);
  }
  
  private VisibilityInfo getVisibilityChangeInfo(TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2)
  {
    VisibilityInfo localVisibilityInfo = new VisibilityInfo(null);
    localVisibilityInfo.mVisibilityChange = false;
    localVisibilityInfo.mFadeIn = false;
    if ((paramTransitionValues1 != null) && (paramTransitionValues1.values.containsKey("android:visibility:visibility")))
    {
      localVisibilityInfo.mStartVisibility = ((Integer)paramTransitionValues1.values.get("android:visibility:visibility")).intValue();
      localVisibilityInfo.mStartParent = ((ViewGroup)paramTransitionValues1.values.get("android:visibility:parent"));
      if ((paramTransitionValues2 == null) || (!paramTransitionValues2.values.containsKey("android:visibility:visibility"))) {
        break label178;
      }
      localVisibilityInfo.mEndVisibility = ((Integer)paramTransitionValues2.values.get("android:visibility:visibility")).intValue();
      localVisibilityInfo.mEndParent = ((ViewGroup)paramTransitionValues2.values.get("android:visibility:parent"));
      label133:
      if ((paramTransitionValues1 == null) || (paramTransitionValues2 == null)) {
        break label278;
      }
      if ((localVisibilityInfo.mStartVisibility != localVisibilityInfo.mEndVisibility) || (localVisibilityInfo.mStartParent != localVisibilityInfo.mEndParent)) {
        break label191;
      }
    }
    label178:
    label191:
    label240:
    label278:
    do
    {
      do
      {
        do
        {
          return localVisibilityInfo;
          localVisibilityInfo.mStartVisibility = -1;
          localVisibilityInfo.mStartParent = null;
          break;
          localVisibilityInfo.mEndVisibility = -1;
          localVisibilityInfo.mEndParent = null;
          break label133;
          if (localVisibilityInfo.mStartVisibility == localVisibilityInfo.mEndVisibility) {
            break label240;
          }
          if (localVisibilityInfo.mStartVisibility == 0)
          {
            localVisibilityInfo.mFadeIn = false;
            localVisibilityInfo.mVisibilityChange = true;
            return localVisibilityInfo;
          }
        } while (localVisibilityInfo.mEndVisibility != 0);
        localVisibilityInfo.mFadeIn = true;
        localVisibilityInfo.mVisibilityChange = true;
        return localVisibilityInfo;
        if (localVisibilityInfo.mEndParent == null)
        {
          localVisibilityInfo.mFadeIn = false;
          localVisibilityInfo.mVisibilityChange = true;
          return localVisibilityInfo;
        }
      } while (localVisibilityInfo.mStartParent != null);
      localVisibilityInfo.mFadeIn = true;
      localVisibilityInfo.mVisibilityChange = true;
      return localVisibilityInfo;
      if ((paramTransitionValues1 == null) && (localVisibilityInfo.mEndVisibility == 0))
      {
        localVisibilityInfo.mFadeIn = true;
        localVisibilityInfo.mVisibilityChange = true;
        return localVisibilityInfo;
      }
    } while ((paramTransitionValues2 != null) || (localVisibilityInfo.mStartVisibility != 0));
    localVisibilityInfo.mFadeIn = false;
    localVisibilityInfo.mVisibilityChange = true;
    return localVisibilityInfo;
  }
  
  public void captureEndValues(@NonNull TransitionValues paramTransitionValues)
  {
    captureValues(paramTransitionValues);
  }
  
  public void captureStartValues(@NonNull TransitionValues paramTransitionValues)
  {
    captureValues(paramTransitionValues);
  }
  
  @Nullable
  public Animator createAnimator(@NonNull ViewGroup paramViewGroup, @Nullable TransitionValues paramTransitionValues1, @Nullable TransitionValues paramTransitionValues2)
  {
    VisibilityInfo localVisibilityInfo = getVisibilityChangeInfo(paramTransitionValues1, paramTransitionValues2);
    if ((localVisibilityInfo.mVisibilityChange) && ((localVisibilityInfo.mStartParent != null) || (localVisibilityInfo.mEndParent != null)))
    {
      if (localVisibilityInfo.mFadeIn) {
        return onAppear(paramViewGroup, paramTransitionValues1, localVisibilityInfo.mStartVisibility, paramTransitionValues2, localVisibilityInfo.mEndVisibility);
      }
      return onDisappear(paramViewGroup, paramTransitionValues1, localVisibilityInfo.mStartVisibility, paramTransitionValues2, localVisibilityInfo.mEndVisibility);
    }
    return null;
  }
  
  public int getMode()
  {
    return this.mMode;
  }
  
  @Nullable
  public String[] getTransitionProperties()
  {
    return sTransitionProperties;
  }
  
  public boolean isTransitionRequired(TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2)
  {
    if ((paramTransitionValues1 == null) && (paramTransitionValues2 == null)) {}
    do
    {
      do
      {
        return false;
      } while ((paramTransitionValues1 != null) && (paramTransitionValues2 != null) && (paramTransitionValues2.values.containsKey("android:visibility:visibility") != paramTransitionValues1.values.containsKey("android:visibility:visibility")));
      paramTransitionValues1 = getVisibilityChangeInfo(paramTransitionValues1, paramTransitionValues2);
    } while ((!paramTransitionValues1.mVisibilityChange) || ((paramTransitionValues1.mStartVisibility != 0) && (paramTransitionValues1.mEndVisibility != 0)));
    return true;
  }
  
  public boolean isVisible(TransitionValues paramTransitionValues)
  {
    if (paramTransitionValues == null) {
      return false;
    }
    int i = ((Integer)paramTransitionValues.values.get("android:visibility:visibility")).intValue();
    paramTransitionValues = (View)paramTransitionValues.values.get("android:visibility:parent");
    if ((i == 0) && (paramTransitionValues != null)) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public Animator onAppear(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, int paramInt1, TransitionValues paramTransitionValues2, int paramInt2)
  {
    if (((this.mMode & 0x1) != 1) || (paramTransitionValues2 == null)) {}
    View localView;
    do
    {
      return null;
      if (paramTransitionValues1 != null) {
        break;
      }
      localView = (View)paramTransitionValues2.view.getParent();
    } while (getVisibilityChangeInfo(getMatchedTransitionValues(localView, false), getTransitionValues(localView, false)).mVisibilityChange);
    return onAppear(paramViewGroup, paramTransitionValues2.view, paramTransitionValues1, paramTransitionValues2);
  }
  
  public Animator onAppear(ViewGroup paramViewGroup, View paramView, TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2)
  {
    return null;
  }
  
  public Animator onDisappear(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, int paramInt1, TransitionValues paramTransitionValues2, int paramInt2)
  {
    if ((this.mMode & 0x2) != 2) {
      return null;
    }
    final Object localObject2;
    final Object localObject1;
    label34:
    Object localObject5;
    Object localObject4;
    Object localObject3;
    if (paramTransitionValues1 != null)
    {
      localObject2 = paramTransitionValues1.view;
      if (paramTransitionValues2 == null) {
        break label194;
      }
      localObject1 = paramTransitionValues2.view;
      localObject5 = null;
      localObject4 = null;
      if ((localObject1 != null) && (((View)localObject1).getParent() != null)) {
        break label379;
      }
      if (localObject1 == null) {
        break label200;
      }
      localObject3 = localObject4;
    }
    for (;;)
    {
      if ((localObject1 != null) && (paramTransitionValues1 != null))
      {
        localObject2 = (int[])paramTransitionValues1.values.get("android:visibility:screenLocation");
        paramInt1 = localObject2[0];
        paramInt2 = localObject2[1];
        localObject2 = new int[2];
        paramViewGroup.getLocationOnScreen((int[])localObject2);
        ((View)localObject1).offsetLeftAndRight(paramInt1 - localObject2[0] - ((View)localObject1).getLeft());
        ((View)localObject1).offsetTopAndBottom(paramInt2 - localObject2[1] - ((View)localObject1).getTop());
        localObject2 = ViewGroupUtils.getOverlay(paramViewGroup);
        ((ViewGroupOverlayImpl)localObject2).add((View)localObject1);
        paramViewGroup = onDisappear(paramViewGroup, (View)localObject1, paramTransitionValues1, paramTransitionValues2);
        if (paramViewGroup == null)
        {
          ((ViewGroupOverlayImpl)localObject2).remove((View)localObject1);
          return paramViewGroup;
          localObject2 = null;
          break;
          label194:
          localObject1 = null;
          break label34;
          label200:
          localObject1 = localObject5;
          localObject3 = localObject4;
          if (localObject2 == null) {
            continue;
          }
          if (((View)localObject2).getParent() == null)
          {
            localObject1 = localObject2;
            localObject3 = localObject4;
            continue;
          }
          localObject1 = localObject5;
          localObject3 = localObject4;
          if (!(((View)localObject2).getParent() instanceof View)) {
            continue;
          }
          View localView = (View)((View)localObject2).getParent();
          if (!getVisibilityChangeInfo(getTransitionValues(localView, true), getMatchedTransitionValues(localView, true)).mVisibilityChange)
          {
            localObject1 = TransitionUtils.copyViewImage(paramViewGroup, (View)localObject2, localView);
            localObject3 = localObject4;
            continue;
          }
          localObject1 = localObject5;
          localObject3 = localObject4;
          if (localView.getParent() != null) {
            continue;
          }
          paramInt1 = localView.getId();
          localObject1 = localObject5;
          localObject3 = localObject4;
          if (paramInt1 == -1) {
            continue;
          }
          localObject1 = localObject5;
          localObject3 = localObject4;
          if (paramViewGroup.findViewById(paramInt1) == null) {
            continue;
          }
          localObject1 = localObject5;
          localObject3 = localObject4;
          if (!this.mCanRemoveViews) {
            continue;
          }
          localObject1 = localObject2;
          localObject3 = localObject4;
          continue;
          label379:
          if (paramInt2 == 4)
          {
            localObject3 = localObject1;
            localObject1 = localObject5;
            continue;
          }
          if (localObject2 == localObject1)
          {
            localObject3 = localObject1;
            localObject1 = localObject5;
            continue;
          }
          localObject1 = localObject2;
          localObject3 = localObject4;
          continue;
        }
        paramViewGroup.addListener(new AnimatorListenerAdapter()
        {
          public void onAnimationEnd(Animator paramAnonymousAnimator)
          {
            localObject2.remove(localObject1);
          }
        });
        return paramViewGroup;
      }
    }
    if (localObject3 != null)
    {
      paramInt1 = ((View)localObject3).getVisibility();
      ViewUtils.setTransitionVisibility((View)localObject3, 0);
      paramViewGroup = onDisappear(paramViewGroup, (View)localObject3, paramTransitionValues1, paramTransitionValues2);
      if (paramViewGroup != null)
      {
        paramTransitionValues1 = new DisappearListener((View)localObject3, paramInt2, true);
        paramViewGroup.addListener(paramTransitionValues1);
        AnimatorUtils.addPauseListener(paramViewGroup, paramTransitionValues1);
        addListener(paramTransitionValues1);
        return paramViewGroup;
      }
      ViewUtils.setTransitionVisibility((View)localObject3, paramInt1);
      return paramViewGroup;
    }
    return null;
  }
  
  public Animator onDisappear(ViewGroup paramViewGroup, View paramView, TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2)
  {
    return null;
  }
  
  public void setMode(int paramInt)
  {
    if ((paramInt & 0xFFFFFFFC) != 0) {
      throw new IllegalArgumentException("Only MODE_IN and MODE_OUT flags are allowed");
    }
    this.mMode = paramInt;
  }
  
  private static class DisappearListener
    extends AnimatorListenerAdapter
    implements Transition.TransitionListener, AnimatorUtilsApi14.AnimatorPauseListenerCompat
  {
    boolean mCanceled = false;
    private final int mFinalVisibility;
    private boolean mLayoutSuppressed;
    private final ViewGroup mParent;
    private final boolean mSuppressLayout;
    private final View mView;
    
    DisappearListener(View paramView, int paramInt, boolean paramBoolean)
    {
      this.mView = paramView;
      this.mFinalVisibility = paramInt;
      this.mParent = ((ViewGroup)paramView.getParent());
      this.mSuppressLayout = paramBoolean;
      suppressLayout(true);
    }
    
    private void hideViewWhenNotCanceled()
    {
      if (!this.mCanceled)
      {
        ViewUtils.setTransitionVisibility(this.mView, this.mFinalVisibility);
        if (this.mParent != null) {
          this.mParent.invalidate();
        }
      }
      suppressLayout(false);
    }
    
    private void suppressLayout(boolean paramBoolean)
    {
      if ((this.mSuppressLayout) && (this.mLayoutSuppressed != paramBoolean) && (this.mParent != null))
      {
        this.mLayoutSuppressed = paramBoolean;
        ViewGroupUtils.suppressLayout(this.mParent, paramBoolean);
      }
    }
    
    public void onAnimationCancel(Animator paramAnimator)
    {
      this.mCanceled = true;
    }
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      hideViewWhenNotCanceled();
    }
    
    public void onAnimationPause(Animator paramAnimator)
    {
      if (!this.mCanceled) {
        ViewUtils.setTransitionVisibility(this.mView, this.mFinalVisibility);
      }
    }
    
    public void onAnimationRepeat(Animator paramAnimator) {}
    
    public void onAnimationResume(Animator paramAnimator)
    {
      if (!this.mCanceled) {
        ViewUtils.setTransitionVisibility(this.mView, 0);
      }
    }
    
    public void onAnimationStart(Animator paramAnimator) {}
    
    public void onTransitionCancel(@NonNull Transition paramTransition) {}
    
    public void onTransitionEnd(@NonNull Transition paramTransition)
    {
      hideViewWhenNotCanceled();
      paramTransition.removeListener(this);
    }
    
    public void onTransitionPause(@NonNull Transition paramTransition)
    {
      suppressLayout(false);
    }
    
    public void onTransitionResume(@NonNull Transition paramTransition)
    {
      suppressLayout(true);
    }
    
    public void onTransitionStart(@NonNull Transition paramTransition) {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({android.support.annotation.RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface Mode {}
  
  private static class VisibilityInfo
  {
    ViewGroup mEndParent;
    int mEndVisibility;
    boolean mFadeIn;
    ViewGroup mStartParent;
    int mStartVisibility;
    boolean mVisibilityChange;
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\Visibility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */