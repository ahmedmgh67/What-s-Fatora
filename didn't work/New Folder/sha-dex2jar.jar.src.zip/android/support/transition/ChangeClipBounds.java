package android.support.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

public class ChangeClipBounds
  extends Transition
{
  private static final String PROPNAME_BOUNDS = "android:clipBounds:bounds";
  private static final String PROPNAME_CLIP = "android:clipBounds:clip";
  private static final String[] sTransitionProperties = { "android:clipBounds:clip" };
  
  public ChangeClipBounds() {}
  
  public ChangeClipBounds(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  private void captureValues(TransitionValues paramTransitionValues)
  {
    Object localObject = paramTransitionValues.view;
    if (((View)localObject).getVisibility() == 8) {}
    Rect localRect;
    do
    {
      return;
      localRect = ViewCompat.getClipBounds((View)localObject);
      paramTransitionValues.values.put("android:clipBounds:clip", localRect);
    } while (localRect != null);
    localObject = new Rect(0, 0, ((View)localObject).getWidth(), ((View)localObject).getHeight());
    paramTransitionValues.values.put("android:clipBounds:bounds", localObject);
  }
  
  public void captureEndValues(@NonNull TransitionValues paramTransitionValues)
  {
    captureValues(paramTransitionValues);
  }
  
  public void captureStartValues(@NonNull TransitionValues paramTransitionValues)
  {
    captureValues(paramTransitionValues);
  }
  
  public Animator createAnimator(@NonNull ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2)
  {
    Object localObject = null;
    paramViewGroup = (ViewGroup)localObject;
    if (paramTransitionValues1 != null)
    {
      paramViewGroup = (ViewGroup)localObject;
      if (paramTransitionValues2 != null)
      {
        paramViewGroup = (ViewGroup)localObject;
        if (paramTransitionValues1.values.containsKey("android:clipBounds:clip"))
        {
          if (paramTransitionValues2.values.containsKey("android:clipBounds:clip")) {
            break label53;
          }
          paramViewGroup = (ViewGroup)localObject;
        }
      }
    }
    label53:
    Rect localRect2;
    Rect localRect3;
    int i;
    label93:
    do
    {
      return paramViewGroup;
      localRect2 = (Rect)paramTransitionValues1.values.get("android:clipBounds:clip");
      localRect3 = (Rect)paramTransitionValues2.values.get("android:clipBounds:clip");
      if (localRect3 != null) {
        break label216;
      }
      i = 1;
      if (localRect2 != null) {
        break;
      }
      paramViewGroup = (ViewGroup)localObject;
    } while (localRect3 == null);
    Rect localRect1;
    if (localRect2 == null)
    {
      localRect1 = (Rect)paramTransitionValues1.values.get("android:clipBounds:bounds");
      paramTransitionValues1 = localRect3;
    }
    for (;;)
    {
      paramViewGroup = (ViewGroup)localObject;
      if (localRect1.equals(paramTransitionValues1)) {
        break;
      }
      ViewCompat.setClipBounds(paramTransitionValues2.view, localRect1);
      paramViewGroup = new RectEvaluator(new Rect());
      paramTransitionValues1 = ObjectAnimator.ofObject(paramTransitionValues2.view, ViewUtils.CLIP_BOUNDS, paramViewGroup, new Rect[] { localRect1, paramTransitionValues1 });
      paramViewGroup = paramTransitionValues1;
      if (i == 0) {
        break;
      }
      paramTransitionValues1.addListener(new AnimatorListenerAdapter()
      {
        public void onAnimationEnd(Animator paramAnonymousAnimator)
        {
          ViewCompat.setClipBounds(this.val$endView, null);
        }
      });
      return paramTransitionValues1;
      label216:
      i = 0;
      break label93;
      paramTransitionValues1 = localRect3;
      localRect1 = localRect2;
      if (localRect3 == null)
      {
        paramTransitionValues1 = (Rect)paramTransitionValues2.values.get("android:clipBounds:bounds");
        localRect1 = localRect2;
      }
    }
  }
  
  public String[] getTransitionProperties()
  {
    return sTransitionProperties;
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\transition\ChangeClipBounds.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */