package android.support.compat;

public final class R
{
  public static final class attr
  {
    public static final int font = 2130968789;
    public static final int fontProviderAuthority = 2130968792;
    public static final int fontProviderCerts = 2130968793;
    public static final int fontProviderFetchStrategy = 2130968794;
    public static final int fontProviderFetchTimeout = 2130968795;
    public static final int fontProviderPackage = 2130968796;
    public static final int fontProviderQuery = 2130968797;
    public static final int fontStyle = 2130968798;
    public static final int fontWeight = 2130968799;
  }
  
  public static final class bool
  {
    public static final int abc_action_bar_embed_tabs = 2131034112;
  }
  
  public static final class color
  {
    public static final int notification_action_color_filter = 2131099749;
    public static final int notification_icon_bg_color = 2131099750;
    public static final int ripple_material_light = 2131099767;
    public static final int secondary_text_default_material_light = 2131099769;
  }
  
  public static final class dimen
  {
    public static final int compat_button_inset_horizontal_material = 2131165292;
    public static final int compat_button_inset_vertical_material = 2131165293;
    public static final int compat_button_padding_horizontal_material = 2131165294;
    public static final int compat_button_padding_vertical_material = 2131165295;
    public static final int compat_control_corner_material = 2131165296;
    public static final int notification_action_icon_size = 2131165367;
    public static final int notification_action_text_size = 2131165368;
    public static final int notification_big_circle_margin = 2131165369;
    public static final int notification_content_margin_start = 2131165370;
    public static final int notification_large_icon_height = 2131165371;
    public static final int notification_large_icon_width = 2131165372;
    public static final int notification_main_column_padding_top = 2131165373;
    public static final int notification_media_narrow_margin = 2131165374;
    public static final int notification_right_icon_size = 2131165375;
    public static final int notification_right_side_padding_top = 2131165376;
    public static final int notification_small_icon_background_padding = 2131165377;
    public static final int notification_small_icon_size_as_large = 2131165378;
    public static final int notification_subtext_size = 2131165379;
    public static final int notification_top_pad = 2131165380;
    public static final int notification_top_pad_large_text = 2131165381;
  }
  
  public static final class drawable
  {
    public static final int notification_action_background = 2131231134;
    public static final int notification_bg = 2131231135;
    public static final int notification_bg_low = 2131231136;
    public static final int notification_bg_low_normal = 2131231137;
    public static final int notification_bg_low_pressed = 2131231138;
    public static final int notification_bg_normal = 2131231139;
    public static final int notification_bg_normal_pressed = 2131231140;
    public static final int notification_icon_background = 2131231141;
    public static final int notification_template_icon_bg = 2131231142;
    public static final int notification_template_icon_low_bg = 2131231143;
    public static final int notification_tile_bg = 2131231144;
    public static final int notify_panel_notification_icon_bg = 2131231145;
  }
  
  public static final class id
  {
    public static final int action_container = 2131296288;
    public static final int action_divider = 2131296290;
    public static final int action_image = 2131296291;
    public static final int action_text = 2131296297;
    public static final int actions = 2131296298;
    public static final int async = 2131296320;
    public static final int blocking = 2131296333;
    public static final int chronometer = 2131296380;
    public static final int forever = 2131296465;
    public static final int icon = 2131296482;
    public static final int icon_group = 2131296483;
    public static final int info = 2131296503;
    public static final int italic = 2131296513;
    public static final int line1 = 2131296535;
    public static final int line3 = 2131296536;
    public static final int normal = 2131296607;
    public static final int notification_background = 2131296608;
    public static final int notification_main_column = 2131296609;
    public static final int notification_main_column_container = 2131296610;
    public static final int right_icon = 2131296645;
    public static final int right_side = 2131296646;
    public static final int text = 2131296725;
    public static final int text2 = 2131296727;
    public static final int time = 2131296738;
    public static final int title = 2131296739;
  }
  
  public static final class integer
  {
    public static final int status_bar_notification_info_maxnum = 2131361807;
  }
  
  public static final class layout
  {
    public static final int notification_action = 2131492964;
    public static final int notification_action_tombstone = 2131492965;
    public static final int notification_template_custom_big = 2131492972;
    public static final int notification_template_icon_group = 2131492973;
    public static final int notification_template_part_chronometer = 2131492977;
    public static final int notification_template_part_time = 2131492978;
  }
  
  public static final class string
  {
    public static final int status_bar_notification_info_overflow = 2131689613;
  }
  
  public static final class style
  {
    public static final int TextAppearance_Compat_Notification = 2131755277;
    public static final int TextAppearance_Compat_Notification_Info = 2131755278;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131755280;
    public static final int TextAppearance_Compat_Notification_Time = 2131755283;
    public static final int TextAppearance_Compat_Notification_Title = 2131755285;
    public static final int Widget_Compat_NotificationActionContainer = 2131755419;
    public static final int Widget_Compat_NotificationActionText = 2131755420;
  }
  
  public static final class styleable
  {
    public static final int[] FontFamily = { 2130968792, 2130968793, 2130968794, 2130968795, 2130968796, 2130968797 };
    public static final int[] FontFamilyFont = { 2130968789, 2130968798, 2130968799 };
    public static final int FontFamilyFont_font = 0;
    public static final int FontFamilyFont_fontStyle = 1;
    public static final int FontFamilyFont_fontWeight = 2;
    public static final int FontFamily_fontProviderAuthority = 0;
    public static final int FontFamily_fontProviderCerts = 1;
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    public static final int FontFamily_fontProviderPackage = 4;
    public static final int FontFamily_fontProviderQuery = 5;
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\compat\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */