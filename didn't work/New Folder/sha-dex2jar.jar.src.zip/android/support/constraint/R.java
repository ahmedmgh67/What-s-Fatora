package android.support.constraint;

public final class R
{
  public static final class attr
  {
    public static final int constraintSet = 2130968729;
    public static final int layout_constraintBaseline_creator = 2130968844;
    public static final int layout_constraintBaseline_toBaselineOf = 2130968845;
    public static final int layout_constraintBottom_creator = 2130968846;
    public static final int layout_constraintBottom_toBottomOf = 2130968847;
    public static final int layout_constraintBottom_toTopOf = 2130968848;
    public static final int layout_constraintDimensionRatio = 2130968849;
    public static final int layout_constraintEnd_toEndOf = 2130968850;
    public static final int layout_constraintEnd_toStartOf = 2130968851;
    public static final int layout_constraintGuide_begin = 2130968852;
    public static final int layout_constraintGuide_end = 2130968853;
    public static final int layout_constraintGuide_percent = 2130968854;
    public static final int layout_constraintHeight_default = 2130968855;
    public static final int layout_constraintHeight_max = 2130968856;
    public static final int layout_constraintHeight_min = 2130968857;
    public static final int layout_constraintHorizontal_bias = 2130968858;
    public static final int layout_constraintHorizontal_chainStyle = 2130968859;
    public static final int layout_constraintHorizontal_weight = 2130968860;
    public static final int layout_constraintLeft_creator = 2130968861;
    public static final int layout_constraintLeft_toLeftOf = 2130968862;
    public static final int layout_constraintLeft_toRightOf = 2130968863;
    public static final int layout_constraintRight_creator = 2130968864;
    public static final int layout_constraintRight_toLeftOf = 2130968865;
    public static final int layout_constraintRight_toRightOf = 2130968866;
    public static final int layout_constraintStart_toEndOf = 2130968867;
    public static final int layout_constraintStart_toStartOf = 2130968868;
    public static final int layout_constraintTop_creator = 2130968869;
    public static final int layout_constraintTop_toBottomOf = 2130968870;
    public static final int layout_constraintTop_toTopOf = 2130968871;
    public static final int layout_constraintVertical_bias = 2130968872;
    public static final int layout_constraintVertical_chainStyle = 2130968873;
    public static final int layout_constraintVertical_weight = 2130968874;
    public static final int layout_constraintWidth_default = 2130968875;
    public static final int layout_constraintWidth_max = 2130968876;
    public static final int layout_constraintWidth_min = 2130968877;
    public static final int layout_editor_absoluteX = 2130968879;
    public static final int layout_editor_absoluteY = 2130968880;
    public static final int layout_goneMarginBottom = 2130968881;
    public static final int layout_goneMarginEnd = 2130968882;
    public static final int layout_goneMarginLeft = 2130968883;
    public static final int layout_goneMarginRight = 2130968884;
    public static final int layout_goneMarginStart = 2130968885;
    public static final int layout_goneMarginTop = 2130968886;
    public static final int layout_optimizationLevel = 2130968889;
  }
  
  public static final class id
  {
    public static final int all = 2131296310;
    public static final int basic = 2131296330;
    public static final int chains = 2131296377;
    public static final int none = 2131296605;
    public static final int packed = 2131296614;
    public static final int parent = 2131296616;
    public static final int spread = 2131296695;
    public static final int spread_inside = 2131296696;
    public static final int wrap = 2131296777;
  }
  
  public static final class styleable
  {
    public static final int[] ConstraintLayout_Layout = { 16842948, 16843039, 16843040, 16843071, 16843072, 2130968729, 2130968844, 2130968845, 2130968846, 2130968847, 2130968848, 2130968849, 2130968850, 2130968851, 2130968852, 2130968853, 2130968854, 2130968855, 2130968856, 2130968857, 2130968858, 2130968859, 2130968860, 2130968861, 2130968862, 2130968863, 2130968864, 2130968865, 2130968866, 2130968867, 2130968868, 2130968869, 2130968870, 2130968871, 2130968872, 2130968873, 2130968874, 2130968875, 2130968876, 2130968877, 2130968879, 2130968880, 2130968881, 2130968882, 2130968883, 2130968884, 2130968885, 2130968886, 2130968889 };
    public static final int ConstraintLayout_Layout_android_maxHeight = 2;
    public static final int ConstraintLayout_Layout_android_maxWidth = 1;
    public static final int ConstraintLayout_Layout_android_minHeight = 4;
    public static final int ConstraintLayout_Layout_android_minWidth = 3;
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    public static final int ConstraintLayout_Layout_constraintSet = 5;
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 6;
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 7;
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 8;
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 9;
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 10;
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 11;
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 12;
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 13;
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 14;
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 15;
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 16;
    public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 17;
    public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 18;
    public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 19;
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 20;
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 21;
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 22;
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 23;
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 24;
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 25;
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 26;
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 27;
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 28;
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 29;
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 30;
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 31;
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 32;
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 33;
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 34;
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 35;
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 36;
    public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 37;
    public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 38;
    public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 39;
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 40;
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 41;
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 42;
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 43;
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 44;
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 45;
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 46;
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 47;
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 48;
    public static final int[] ConstraintSet = { 16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968844, 2130968845, 2130968846, 2130968847, 2130968848, 2130968849, 2130968850, 2130968851, 2130968852, 2130968853, 2130968854, 2130968855, 2130968856, 2130968857, 2130968858, 2130968859, 2130968860, 2130968861, 2130968862, 2130968863, 2130968864, 2130968865, 2130968866, 2130968867, 2130968868, 2130968869, 2130968870, 2130968871, 2130968872, 2130968873, 2130968874, 2130968875, 2130968876, 2130968877, 2130968879, 2130968880, 2130968881, 2130968882, 2130968883, 2130968884, 2130968885, 2130968886 };
    public static final int ConstraintSet_android_alpha = 9;
    public static final int ConstraintSet_android_elevation = 21;
    public static final int ConstraintSet_android_id = 1;
    public static final int ConstraintSet_android_layout_height = 4;
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    public static final int ConstraintSet_android_layout_marginEnd = 19;
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    public static final int ConstraintSet_android_layout_marginRight = 7;
    public static final int ConstraintSet_android_layout_marginStart = 18;
    public static final int ConstraintSet_android_layout_marginTop = 6;
    public static final int ConstraintSet_android_layout_width = 3;
    public static final int ConstraintSet_android_orientation = 0;
    public static final int ConstraintSet_android_rotationX = 16;
    public static final int ConstraintSet_android_rotationY = 17;
    public static final int ConstraintSet_android_scaleX = 14;
    public static final int ConstraintSet_android_scaleY = 15;
    public static final int ConstraintSet_android_transformPivotX = 10;
    public static final int ConstraintSet_android_transformPivotY = 11;
    public static final int ConstraintSet_android_translationX = 12;
    public static final int ConstraintSet_android_translationY = 13;
    public static final int ConstraintSet_android_translationZ = 20;
    public static final int ConstraintSet_android_visibility = 2;
    public static final int ConstraintSet_layout_constraintBaseline_creator = 22;
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 23;
    public static final int ConstraintSet_layout_constraintBottom_creator = 24;
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 25;
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 26;
    public static final int ConstraintSet_layout_constraintDimensionRatio = 27;
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 28;
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 29;
    public static final int ConstraintSet_layout_constraintGuide_begin = 30;
    public static final int ConstraintSet_layout_constraintGuide_end = 31;
    public static final int ConstraintSet_layout_constraintGuide_percent = 32;
    public static final int ConstraintSet_layout_constraintHeight_default = 33;
    public static final int ConstraintSet_layout_constraintHeight_max = 34;
    public static final int ConstraintSet_layout_constraintHeight_min = 35;
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 36;
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 37;
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 38;
    public static final int ConstraintSet_layout_constraintLeft_creator = 39;
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 40;
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 41;
    public static final int ConstraintSet_layout_constraintRight_creator = 42;
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 43;
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 44;
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 45;
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 46;
    public static final int ConstraintSet_layout_constraintTop_creator = 47;
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 48;
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 49;
    public static final int ConstraintSet_layout_constraintVertical_bias = 50;
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 51;
    public static final int ConstraintSet_layout_constraintVertical_weight = 52;
    public static final int ConstraintSet_layout_constraintWidth_default = 53;
    public static final int ConstraintSet_layout_constraintWidth_max = 54;
    public static final int ConstraintSet_layout_constraintWidth_min = 55;
    public static final int ConstraintSet_layout_editor_absoluteX = 56;
    public static final int ConstraintSet_layout_editor_absoluteY = 57;
    public static final int ConstraintSet_layout_goneMarginBottom = 58;
    public static final int ConstraintSet_layout_goneMarginEnd = 59;
    public static final int ConstraintSet_layout_goneMarginLeft = 60;
    public static final int ConstraintSet_layout_goneMarginRight = 61;
    public static final int ConstraintSet_layout_goneMarginStart = 62;
    public static final int ConstraintSet_layout_goneMarginTop = 63;
    public static final int[] LinearConstraintLayout = { 16842948 };
    public static final int LinearConstraintLayout_android_orientation = 0;
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\constraint\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */