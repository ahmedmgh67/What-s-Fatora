package android.support.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

final class MultiDexExtractor
{
  private static final int BUFFER_SIZE = 16384;
  private static final String DEX_PREFIX = "classes";
  private static final String DEX_SUFFIX = ".dex";
  private static final String EXTRACTED_NAME_EXT = ".classes";
  private static final String EXTRACTED_SUFFIX = ".zip";
  private static final String KEY_CRC = "crc";
  private static final String KEY_DEX_CRC = "dex.crc.";
  private static final String KEY_DEX_NUMBER = "dex.number";
  private static final String KEY_DEX_TIME = "dex.time.";
  private static final String KEY_TIME_STAMP = "timestamp";
  private static final String LOCK_FILENAME = "MultiDex.lock";
  private static final int MAX_EXTRACT_ATTEMPTS = 3;
  private static final long NO_VALUE = -1L;
  private static final String PREFS_FILE = "multidex.version";
  private static final String TAG = "MultiDex";
  
  private static void closeQuietly(Closeable paramCloseable)
  {
    try
    {
      paramCloseable.close();
      return;
    }
    catch (IOException paramCloseable)
    {
      Log.w("MultiDex", "Failed to close resource", paramCloseable);
    }
  }
  
  private static void extract(ZipFile paramZipFile, ZipEntry paramZipEntry, File paramFile, String paramString)
    throws IOException, FileNotFoundException
  {
    InputStream localInputStream = paramZipFile.getInputStream(paramZipEntry);
    paramString = File.createTempFile("tmp-" + paramString, ".zip", paramFile.getParentFile());
    Log.i("MultiDex", "Extracting " + paramString.getPath());
    for (;;)
    {
      try
      {
        paramZipFile = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(paramString)));
      }
      finally
      {
        ZipEntry localZipEntry;
        int i;
        continue;
      }
      try
      {
        localZipEntry = new ZipEntry("classes.dex");
        localZipEntry.setTime(paramZipEntry.getTime());
        paramZipFile.putNextEntry(localZipEntry);
        paramZipEntry = new byte['䀀'];
        i = localInputStream.read(paramZipEntry);
        if (i != -1)
        {
          paramZipFile.write(paramZipEntry, 0, i);
          i = localInputStream.read(paramZipEntry);
        }
        else
        {
          paramZipFile.closeEntry();
          try
          {
            paramZipFile.close();
            if (paramString.setReadOnly()) {
              continue;
            }
            throw new IOException("Failed to mark readonly \"" + paramString.getAbsolutePath() + "\" (tmp of \"" + paramFile.getAbsolutePath() + "\")");
          }
          finally {}
          closeQuietly(localInputStream);
          paramString.delete();
          throw paramZipFile;
        }
      }
      finally
      {
        paramZipFile.close();
      }
    }
    Log.i("MultiDex", "Renaming to " + paramFile.getPath());
    if (!paramString.renameTo(paramFile)) {
      throw new IOException("Failed to rename \"" + paramString.getAbsolutePath() + "\" to \"" + paramFile.getAbsolutePath() + "\"");
    }
    closeQuietly(localInputStream);
    paramString.delete();
  }
  
  private static SharedPreferences getMultiDexPreferences(Context paramContext)
  {
    if (Build.VERSION.SDK_INT < 11) {}
    for (int i = 0;; i = 4) {
      return paramContext.getSharedPreferences("multidex.version", i);
    }
  }
  
  private static long getTimeStamp(File paramFile)
  {
    long l2 = paramFile.lastModified();
    long l1 = l2;
    if (l2 == -1L) {
      l1 = l2 - 1L;
    }
    return l1;
  }
  
  private static long getZipCrc(File paramFile)
    throws IOException
  {
    long l2 = ZipUtil.getZipCrc(paramFile);
    long l1 = l2;
    if (l2 == -1L) {
      l1 = l2 - 1L;
    }
    return l1;
  }
  
  private static boolean isModified(Context paramContext, File paramFile, long paramLong, String paramString)
  {
    paramContext = getMultiDexPreferences(paramContext);
    return (paramContext.getLong(paramString + "timestamp", -1L) != getTimeStamp(paramFile)) || (paramContext.getLong(paramString + "crc", -1L) != paramLong);
  }
  
  /* Error */
  static List<? extends File> load(Context paramContext, File paramFile1, File paramFile2, String paramString, boolean paramBoolean)
    throws IOException
  {
    // Byte code:
    //   0: ldc 55
    //   2: new 89	java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   9: ldc -20
    //   11: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   14: aload_1
    //   15: invokevirtual 115	java/io/File:getPath	()Ljava/lang/String;
    //   18: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: ldc -18
    //   23: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: iload 4
    //   28: invokevirtual 241	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   31: ldc -18
    //   33: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   36: aload_3
    //   37: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: ldc -13
    //   42: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   48: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   51: pop
    //   52: aload_1
    //   53: invokestatic 244	android/support/multidex/MultiDexExtractor:getZipCrc	(Ljava/io/File;)J
    //   56: lstore 5
    //   58: new 102	java/io/File
    //   61: dup
    //   62: aload_2
    //   63: ldc 43
    //   65: invokespecial 247	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   68: astore 14
    //   70: new 249	java/io/RandomAccessFile
    //   73: dup
    //   74: aload 14
    //   76: ldc -5
    //   78: invokespecial 252	java/io/RandomAccessFile:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   81: astore 13
    //   83: aconst_null
    //   84: astore 8
    //   86: aconst_null
    //   87: astore 11
    //   89: aconst_null
    //   90: astore 10
    //   92: aload 11
    //   94: astore 7
    //   96: aload 13
    //   98: invokevirtual 256	java/io/RandomAccessFile:getChannel	()Ljava/nio/channels/FileChannel;
    //   101: astore 9
    //   103: aload 11
    //   105: astore 7
    //   107: aload 9
    //   109: astore 8
    //   111: ldc 55
    //   113: new 89	java/lang/StringBuilder
    //   116: dup
    //   117: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   120: ldc_w 258
    //   123: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: aload 14
    //   128: invokevirtual 115	java/io/File:getPath	()Ljava/lang/String;
    //   131: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   137: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   140: pop
    //   141: aload 11
    //   143: astore 7
    //   145: aload 9
    //   147: astore 8
    //   149: aload 9
    //   151: invokevirtual 264	java/nio/channels/FileChannel:lock	()Ljava/nio/channels/FileLock;
    //   154: astore 11
    //   156: aload 11
    //   158: astore 7
    //   160: aload 9
    //   162: astore 8
    //   164: ldc 55
    //   166: new 89	java/lang/StringBuilder
    //   169: dup
    //   170: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   173: aload 14
    //   175: invokevirtual 115	java/io/File:getPath	()Ljava/lang/String;
    //   178: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: ldc_w 266
    //   184: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   190: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   193: pop
    //   194: iload 4
    //   196: ifne +171 -> 367
    //   199: aload 11
    //   201: astore 7
    //   203: aload 9
    //   205: astore 8
    //   207: aload_0
    //   208: aload_1
    //   209: lload 5
    //   211: aload_3
    //   212: invokestatic 268	android/support/multidex/MultiDexExtractor:isModified	(Landroid/content/Context;Ljava/io/File;JLjava/lang/String;)Z
    //   215: istore 4
    //   217: iload 4
    //   219: ifne +148 -> 367
    //   222: aload 11
    //   224: astore 7
    //   226: aload 9
    //   228: astore 8
    //   230: aload_0
    //   231: aload_1
    //   232: aload_2
    //   233: aload_3
    //   234: invokestatic 272	android/support/multidex/MultiDexExtractor:loadExistingExtractions	(Landroid/content/Context;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)Ljava/util/List;
    //   237: astore 12
    //   239: aload 12
    //   241: astore_0
    //   242: aload 10
    //   244: astore_1
    //   245: aload 11
    //   247: ifnull +11 -> 258
    //   250: aload 11
    //   252: invokevirtual 277	java/nio/channels/FileLock:release	()V
    //   255: aload 10
    //   257: astore_1
    //   258: aload 9
    //   260: ifnull +8 -> 268
    //   263: aload 9
    //   265: invokestatic 181	android/support/multidex/MultiDexExtractor:closeQuietly	(Ljava/io/Closeable;)V
    //   268: aload 13
    //   270: invokestatic 181	android/support/multidex/MultiDexExtractor:closeQuietly	(Ljava/io/Closeable;)V
    //   273: aload_1
    //   274: ifnull +217 -> 491
    //   277: aload_1
    //   278: athrow
    //   279: astore 12
    //   281: aload 11
    //   283: astore 7
    //   285: aload 9
    //   287: astore 8
    //   289: ldc 55
    //   291: ldc_w 279
    //   294: aload 12
    //   296: invokestatic 77	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   299: pop
    //   300: aload 11
    //   302: astore 7
    //   304: aload 9
    //   306: astore 8
    //   308: aload_1
    //   309: aload_2
    //   310: invokestatic 283	android/support/multidex/MultiDexExtractor:performExtractions	(Ljava/io/File;Ljava/io/File;)Ljava/util/List;
    //   313: astore_2
    //   314: aload 11
    //   316: astore 7
    //   318: aload 9
    //   320: astore 8
    //   322: aload_0
    //   323: aload_3
    //   324: aload_1
    //   325: invokestatic 232	android/support/multidex/MultiDexExtractor:getTimeStamp	(Ljava/io/File;)J
    //   328: lload 5
    //   330: aload_2
    //   331: invokestatic 287	android/support/multidex/MultiDexExtractor:putStoredApkInfo	(Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   334: aload_2
    //   335: astore_0
    //   336: goto -94 -> 242
    //   339: astore_0
    //   340: aload 7
    //   342: ifnull +8 -> 350
    //   345: aload 7
    //   347: invokevirtual 277	java/nio/channels/FileLock:release	()V
    //   350: aload 8
    //   352: ifnull +8 -> 360
    //   355: aload 8
    //   357: invokestatic 181	android/support/multidex/MultiDexExtractor:closeQuietly	(Ljava/io/Closeable;)V
    //   360: aload 13
    //   362: invokestatic 181	android/support/multidex/MultiDexExtractor:closeQuietly	(Ljava/io/Closeable;)V
    //   365: aload_0
    //   366: athrow
    //   367: aload 11
    //   369: astore 7
    //   371: aload 9
    //   373: astore 8
    //   375: ldc 55
    //   377: ldc_w 289
    //   380: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   383: pop
    //   384: aload 11
    //   386: astore 7
    //   388: aload 9
    //   390: astore 8
    //   392: aload_1
    //   393: aload_2
    //   394: invokestatic 283	android/support/multidex/MultiDexExtractor:performExtractions	(Ljava/io/File;Ljava/io/File;)Ljava/util/List;
    //   397: astore_2
    //   398: aload 11
    //   400: astore 7
    //   402: aload 9
    //   404: astore 8
    //   406: aload_0
    //   407: aload_3
    //   408: aload_1
    //   409: invokestatic 232	android/support/multidex/MultiDexExtractor:getTimeStamp	(Ljava/io/File;)J
    //   412: lload 5
    //   414: aload_2
    //   415: invokestatic 287	android/support/multidex/MultiDexExtractor:putStoredApkInfo	(Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   418: aload_2
    //   419: astore_0
    //   420: goto -178 -> 242
    //   423: astore_1
    //   424: ldc 55
    //   426: new 89	java/lang/StringBuilder
    //   429: dup
    //   430: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   433: ldc_w 291
    //   436: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   439: aload 14
    //   441: invokevirtual 115	java/io/File:getPath	()Ljava/lang/String;
    //   444: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   447: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   450: invokestatic 294	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   453: pop
    //   454: goto -196 -> 258
    //   457: astore_1
    //   458: ldc 55
    //   460: new 89	java/lang/StringBuilder
    //   463: dup
    //   464: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   467: ldc_w 291
    //   470: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   473: aload 14
    //   475: invokevirtual 115	java/io/File:getPath	()Ljava/lang/String;
    //   478: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   481: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   484: invokestatic 294	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   487: pop
    //   488: goto -138 -> 350
    //   491: ldc 55
    //   493: new 89	java/lang/StringBuilder
    //   496: dup
    //   497: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   500: ldc_w 296
    //   503: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: aload_0
    //   507: invokeinterface 302 1 0
    //   512: invokevirtual 305	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   515: ldc_w 307
    //   518: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   521: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   524: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   527: pop
    //   528: aload_0
    //   529: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	530	0	paramContext	Context
    //   0	530	1	paramFile1	File
    //   0	530	2	paramFile2	File
    //   0	530	3	paramString	String
    //   0	530	4	paramBoolean	boolean
    //   56	357	5	l	long
    //   94	307	7	localFileLock1	java.nio.channels.FileLock
    //   84	321	8	localObject1	Object
    //   101	302	9	localFileChannel	java.nio.channels.FileChannel
    //   90	166	10	localObject2	Object
    //   87	312	11	localFileLock2	java.nio.channels.FileLock
    //   237	3	12	localList	List
    //   279	16	12	localIOException	IOException
    //   81	280	13	localRandomAccessFile	java.io.RandomAccessFile
    //   68	406	14	localFile	File
    // Exception table:
    //   from	to	target	type
    //   230	239	279	java/io/IOException
    //   96	103	339	finally
    //   111	141	339	finally
    //   149	156	339	finally
    //   164	194	339	finally
    //   207	217	339	finally
    //   230	239	339	finally
    //   289	300	339	finally
    //   308	314	339	finally
    //   322	334	339	finally
    //   375	384	339	finally
    //   392	398	339	finally
    //   406	418	339	finally
    //   250	255	423	java/io/IOException
    //   345	350	457	java/io/IOException
  }
  
  private static List<ExtractedDex> loadExistingExtractions(Context paramContext, File paramFile1, File paramFile2, String paramString)
    throws IOException
  {
    Log.i("MultiDex", "loading existing secondary dex files");
    paramFile1 = paramFile1.getName() + ".classes";
    paramContext = getMultiDexPreferences(paramContext);
    int j = paramContext.getInt(paramString + "dex.number", 1);
    ArrayList localArrayList = new ArrayList(j - 1);
    int i = 2;
    while (i <= j)
    {
      ExtractedDex localExtractedDex = new ExtractedDex(paramFile2, paramFile1 + i + ".zip");
      if (localExtractedDex.isFile())
      {
        localExtractedDex.crc = getZipCrc(localExtractedDex);
        long l1 = paramContext.getLong(paramString + "dex.crc." + i, -1L);
        long l2 = paramContext.getLong(paramString + "dex.time." + i, -1L);
        long l3 = localExtractedDex.lastModified();
        if ((l2 != l3) || (l1 != localExtractedDex.crc)) {
          throw new IOException("Invalid extracted dex: " + localExtractedDex + " (key \"" + paramString + "\"), expected modification time: " + l2 + ", modification time: " + l3 + ", expected crc: " + l1 + ", file crc: " + localExtractedDex.crc);
        }
        localArrayList.add(localExtractedDex);
        i += 1;
      }
      else
      {
        throw new IOException("Missing extracted secondary dex file '" + localExtractedDex.getPath() + "'");
      }
    }
    return localArrayList;
  }
  
  /* Error */
  private static List<ExtractedDex> performExtractions(File paramFile1, File paramFile2)
    throws IOException
  {
    // Byte code:
    //   0: new 89	java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   7: aload_0
    //   8: invokevirtual 314	java/io/File:getName	()Ljava/lang/String;
    //   11: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   14: ldc 22
    //   16: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   19: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   22: astore 9
    //   24: aload_1
    //   25: aload 9
    //   27: invokestatic 361	android/support/multidex/MultiDexExtractor:prepareDexDir	(Ljava/io/File;Ljava/lang/String;)V
    //   30: new 320	java/util/ArrayList
    //   33: dup
    //   34: invokespecial 362	java/util/ArrayList:<init>	()V
    //   37: astore 8
    //   39: new 83	java/util/zip/ZipFile
    //   42: dup
    //   43: aload_0
    //   44: invokespecial 363	java/util/zip/ZipFile:<init>	(Ljava/io/File;)V
    //   47: astore 10
    //   49: iconst_2
    //   50: istore_3
    //   51: aload 10
    //   53: new 89	java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   60: ldc 16
    //   62: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: iconst_2
    //   66: invokevirtual 305	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   69: ldc 19
    //   71: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   77: invokevirtual 367	java/util/zip/ZipFile:getEntry	(Ljava/lang/String;)Ljava/util/zip/ZipEntry;
    //   80: astore_0
    //   81: aload_0
    //   82: ifnull +415 -> 497
    //   85: new 8	android/support/multidex/MultiDexExtractor$ExtractedDex
    //   88: dup
    //   89: aload_1
    //   90: new 89	java/lang/StringBuilder
    //   93: dup
    //   94: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   97: aload 9
    //   99: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: iload_3
    //   103: invokevirtual 305	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   106: ldc 25
    //   108: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   114: invokespecial 324	android/support/multidex/MultiDexExtractor$ExtractedDex:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   117: astore 11
    //   119: aload 8
    //   121: aload 11
    //   123: invokeinterface 352 2 0
    //   128: pop
    //   129: ldc 55
    //   131: new 89	java/lang/StringBuilder
    //   134: dup
    //   135: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   138: ldc_w 369
    //   141: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: aload 11
    //   146: invokevirtual 335	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   149: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   152: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   155: pop
    //   156: iconst_0
    //   157: istore 4
    //   159: iconst_0
    //   160: istore 5
    //   162: iload 4
    //   164: iconst_3
    //   165: if_icmpge +243 -> 408
    //   168: iload 5
    //   170: ifne +238 -> 408
    //   173: iload 4
    //   175: iconst_1
    //   176: iadd
    //   177: istore 6
    //   179: aload 10
    //   181: aload_0
    //   182: aload 11
    //   184: aload 9
    //   186: invokestatic 371	android/support/multidex/MultiDexExtractor:extract	(Ljava/util/zip/ZipFile;Ljava/util/zip/ZipEntry;Ljava/io/File;Ljava/lang/String;)V
    //   189: aload 11
    //   191: aload 11
    //   193: invokestatic 244	android/support/multidex/MultiDexExtractor:getZipCrc	(Ljava/io/File;)J
    //   196: putfield 329	android/support/multidex/MultiDexExtractor$ExtractedDex:crc	J
    //   199: iconst_1
    //   200: istore_2
    //   201: new 89	java/lang/StringBuilder
    //   204: dup
    //   205: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   208: ldc_w 373
    //   211: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: astore 12
    //   216: iload_2
    //   217: ifeq +314 -> 531
    //   220: ldc_w 375
    //   223: astore 7
    //   225: ldc 55
    //   227: aload 12
    //   229: aload 7
    //   231: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   234: ldc_w 377
    //   237: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: aload 11
    //   242: invokevirtual 378	android/support/multidex/MultiDexExtractor$ExtractedDex:getAbsolutePath	()Ljava/lang/String;
    //   245: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   248: ldc_w 380
    //   251: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: aload 11
    //   256: invokevirtual 383	android/support/multidex/MultiDexExtractor$ExtractedDex:length	()J
    //   259: invokevirtual 342	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   262: ldc_w 385
    //   265: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   268: aload 11
    //   270: getfield 329	android/support/multidex/MultiDexExtractor$ExtractedDex:crc	J
    //   273: invokevirtual 342	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   276: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   279: invokestatic 119	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   282: pop
    //   283: iload_2
    //   284: istore 5
    //   286: iload 6
    //   288: istore 4
    //   290: iload_2
    //   291: ifne -129 -> 162
    //   294: aload 11
    //   296: invokevirtual 386	android/support/multidex/MultiDexExtractor$ExtractedDex:delete	()Z
    //   299: pop
    //   300: iload_2
    //   301: istore 5
    //   303: iload 6
    //   305: istore 4
    //   307: aload 11
    //   309: invokevirtual 389	android/support/multidex/MultiDexExtractor$ExtractedDex:exists	()Z
    //   312: ifeq -150 -> 162
    //   315: ldc 55
    //   317: new 89	java/lang/StringBuilder
    //   320: dup
    //   321: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   324: ldc_w 391
    //   327: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   330: aload 11
    //   332: invokevirtual 355	android/support/multidex/MultiDexExtractor$ExtractedDex:getPath	()Ljava/lang/String;
    //   335: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   338: ldc_w 357
    //   341: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   344: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   347: invokestatic 393	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   350: pop
    //   351: iload_2
    //   352: istore 5
    //   354: iload 6
    //   356: istore 4
    //   358: goto -196 -> 162
    //   361: astore_0
    //   362: aload 10
    //   364: invokevirtual 394	java/util/zip/ZipFile:close	()V
    //   367: aload_0
    //   368: athrow
    //   369: astore 7
    //   371: iconst_0
    //   372: istore_2
    //   373: ldc 55
    //   375: new 89	java/lang/StringBuilder
    //   378: dup
    //   379: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   382: ldc_w 396
    //   385: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   388: aload 11
    //   390: invokevirtual 378	android/support/multidex/MultiDexExtractor$ExtractedDex:getAbsolutePath	()Ljava/lang/String;
    //   393: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   396: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   399: aload 7
    //   401: invokestatic 77	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   404: pop
    //   405: goto -204 -> 201
    //   408: iload 5
    //   410: ifne +50 -> 460
    //   413: new 64	java/io/IOException
    //   416: dup
    //   417: new 89	java/lang/StringBuilder
    //   420: dup
    //   421: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   424: ldc_w 398
    //   427: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   430: aload 11
    //   432: invokevirtual 378	android/support/multidex/MultiDexExtractor$ExtractedDex:getAbsolutePath	()Ljava/lang/String;
    //   435: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   438: ldc_w 400
    //   441: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: iload_3
    //   445: invokevirtual 305	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   448: ldc -13
    //   450: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   453: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   456: invokespecial 179	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   459: athrow
    //   460: iload_3
    //   461: iconst_1
    //   462: iadd
    //   463: istore_3
    //   464: aload 10
    //   466: new 89	java/lang/StringBuilder
    //   469: dup
    //   470: invokespecial 90	java/lang/StringBuilder:<init>	()V
    //   473: ldc 16
    //   475: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   478: iload_3
    //   479: invokevirtual 305	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   482: ldc 19
    //   484: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   487: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   490: invokevirtual 367	java/util/zip/ZipFile:getEntry	(Ljava/lang/String;)Ljava/util/zip/ZipEntry;
    //   493: astore_0
    //   494: goto -413 -> 81
    //   497: aload 10
    //   499: invokevirtual 394	java/util/zip/ZipFile:close	()V
    //   502: aload 8
    //   504: areturn
    //   505: astore_0
    //   506: ldc 55
    //   508: ldc 71
    //   510: aload_0
    //   511: invokestatic 77	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   514: pop
    //   515: aload 8
    //   517: areturn
    //   518: astore_1
    //   519: ldc 55
    //   521: ldc 71
    //   523: aload_1
    //   524: invokestatic 77	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   527: pop
    //   528: goto -161 -> 367
    //   531: ldc_w 402
    //   534: astore 7
    //   536: goto -311 -> 225
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	539	0	paramFile1	File
    //   0	539	1	paramFile2	File
    //   200	173	2	i	int
    //   50	429	3	j	int
    //   157	200	4	k	int
    //   160	249	5	m	int
    //   177	178	6	n	int
    //   223	7	7	str1	String
    //   369	31	7	localIOException	IOException
    //   534	1	7	str2	String
    //   37	479	8	localArrayList	ArrayList
    //   22	163	9	str3	String
    //   47	451	10	localZipFile	ZipFile
    //   117	314	11	localExtractedDex	ExtractedDex
    //   214	14	12	localStringBuilder	StringBuilder
    // Exception table:
    //   from	to	target	type
    //   51	81	361	finally
    //   85	156	361	finally
    //   179	189	361	finally
    //   189	199	361	finally
    //   201	216	361	finally
    //   225	283	361	finally
    //   294	300	361	finally
    //   307	351	361	finally
    //   373	405	361	finally
    //   413	460	361	finally
    //   464	494	361	finally
    //   189	199	369	java/io/IOException
    //   497	502	505	java/io/IOException
    //   362	367	518	java/io/IOException
  }
  
  private static void prepareDexDir(File paramFile, String paramString)
  {
    paramString = paramFile.listFiles(new FileFilter()
    {
      public boolean accept(File paramAnonymousFile)
      {
        paramAnonymousFile = paramAnonymousFile.getName();
        return (!paramAnonymousFile.startsWith(this.val$extractedFilePrefix)) && (!paramAnonymousFile.equals("MultiDex.lock"));
      }
    });
    if (paramString == null)
    {
      Log.w("MultiDex", "Failed to list secondary dex dir content (" + paramFile.getPath() + ").");
      return;
    }
    int j = paramString.length;
    int i = 0;
    label58:
    if (i < j)
    {
      paramFile = paramString[i];
      Log.i("MultiDex", "Trying to delete old file " + paramFile.getPath() + " of size " + paramFile.length());
      if (paramFile.delete()) {
        break label152;
      }
      Log.w("MultiDex", "Failed to delete old file " + paramFile.getPath());
    }
    for (;;)
    {
      i += 1;
      break label58;
      break;
      label152:
      Log.i("MultiDex", "Deleted old file " + paramFile.getPath());
    }
  }
  
  private static void putStoredApkInfo(Context paramContext, String paramString, long paramLong1, long paramLong2, List<ExtractedDex> paramList)
  {
    paramContext = getMultiDexPreferences(paramContext).edit();
    paramContext.putLong(paramString + "timestamp", paramLong1);
    paramContext.putLong(paramString + "crc", paramLong2);
    paramContext.putInt(paramString + "dex.number", paramList.size() + 1);
    int i = 2;
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      ExtractedDex localExtractedDex = (ExtractedDex)paramList.next();
      paramContext.putLong(paramString + "dex.crc." + i, localExtractedDex.crc);
      paramContext.putLong(paramString + "dex.time." + i, localExtractedDex.lastModified());
      i += 1;
    }
    paramContext.commit();
  }
  
  private static class ExtractedDex
    extends File
  {
    public long crc = -1L;
    
    public ExtractedDex(File paramFile, String paramString)
    {
      super(paramString);
    }
  }
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\multidex\MultiDexExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */