package android.support.design;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "android.support.design";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = -1;
  public static final String VERSION_NAME = "";
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\support\design\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */