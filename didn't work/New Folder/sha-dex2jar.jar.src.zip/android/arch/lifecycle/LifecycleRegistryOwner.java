package android.arch.lifecycle;

@Deprecated
public abstract interface LifecycleRegistryOwner
  extends LifecycleOwner
{
  public abstract LifecycleRegistry getLifecycle();
}


/* Location:              H:\decode\dex2jar-2.0\sha-dex2jar.jar!\android\arch\lifecycle\LifecycleRegistryOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */