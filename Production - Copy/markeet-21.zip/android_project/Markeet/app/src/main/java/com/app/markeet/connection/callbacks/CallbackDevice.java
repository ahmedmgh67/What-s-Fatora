package com.app.markeet.connection.callbacks;

import java.io.Serializable;

public class CallbackDevice implements Serializable {
    public String status = "";
    public String message = "";
}
