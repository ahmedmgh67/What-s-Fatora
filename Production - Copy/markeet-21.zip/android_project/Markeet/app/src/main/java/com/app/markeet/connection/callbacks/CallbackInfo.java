package com.app.markeet.connection.callbacks;

import com.app.markeet.model.Info;

import java.io.Serializable;

public class CallbackInfo implements Serializable {
    public String status = "";
    public Info info = null;
}
