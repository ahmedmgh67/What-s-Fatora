package com.app.markeet.model;

public class NewsInfo {

    public Long id;
    public String title;
    public String brief_content;
    public String full_content;
    public String image;
    public Integer draft;
    public String status;
    public Long created_at;
    public Long last_update;

}
